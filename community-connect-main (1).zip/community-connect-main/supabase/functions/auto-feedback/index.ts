import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const feedbackQuestionTemplates = [
  {
    question: "How would you rate your overall experience with AstraChat today?",
    questionType: "star_rating",
    options: null,
    context: "general",
  },
  {
    question: "How helpful was the AI assistant for your needs?",
    questionType: "star_rating",
    options: null,
    context: "ai_usage",
  },
  {
    question: "What best describes your experience chatting with our AI?",
    questionType: "options",
    options: ["Very Helpful 🌟", "Good 👍", "Okay 😊", "Needs Improvement 🔧"],
    context: "ai_quality",
  },
  {
    question: "How easy was it to use AstraChat features?",
    questionType: "options",
    options: ["Super Easy! 🚀", "Pretty Easy 👌", "It's Okay 🤔", "A bit tricky 😅"],
    context: "usability",
  },
  {
    question: "Would you recommend AstraChat to your friends?",
    questionType: "options",
    options: ["Definitely! 💯", "Probably Yes 👍", "Maybe 🤔", "Not Sure 😕"],
    context: "nps",
  },
];

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { userId, forceGenerate = false } = await req.json();

    if (!userId) {
      return new Response(
        JSON.stringify({ sent: false, reason: "No userId provided" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Check timing - don't spam feedback
    if (!forceGenerate) {
      const { data: recentFeedback } = await supabase
        .from('feedback_requests')
        .select('created_at')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(1);

      const lastTime = recentFeedback?.[0]?.created_at;
      if (lastTime) {
        const hoursSince = (Date.now() - new Date(lastTime).getTime()) / (1000 * 60 * 60);
        if (hoursSince < 24) {
          return new Response(
            JSON.stringify({ sent: false, reason: `Last feedback ${hoursSince.toFixed(1)}h ago` }),
            { headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
      }
    }

    // Pick a random question
    const selected = feedbackQuestionTemplates[Math.floor(Math.random() * feedbackQuestionTemplates.length)];

    // Insert using only columns that exist in the schema
    const { data: newRequest, error: insertError } = await supabase
      .from('feedback_requests')
      .insert({
        user_id: userId,
        question: selected.question,
        question_type: selected.questionType,
        options: selected.options,
        context: selected.context,
        expires_at: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
      })
      .select()
      .single();

    if (insertError) throw insertError;

    return new Response(
      JSON.stringify({ sent: true, request: newRequest }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Auto-feedback error:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
