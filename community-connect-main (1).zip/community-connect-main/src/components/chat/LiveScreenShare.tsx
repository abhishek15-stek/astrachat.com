import React, { useState, useRef, useEffect, useCallback } from 'react';
import { 
  Monitor, 
  Mic, 
  MicOff, 
  Video, 
  VideoOff, 
  PhoneOff, 
  Maximize2, 
  Minimize2,
  X,
  Check,
  Wifi,
  WifiOff,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { cn } from '@/lib/utils';
import { useScreenShare } from '@/hooks/useScreenShare';
import { motion, AnimatePresence } from 'framer-motion';

interface LiveScreenShareProps {
  receiverId?: string;
  receiverName?: string;
  isOpen: boolean;
  onClose: () => void;
}

export function LiveScreenShare({ receiverId, receiverName, isOpen, onClose }: LiveScreenShareProps) {
  const {
    isSharing,
    isViewing,
    localStream,
    remoteStream,
    pendingRequest,
    startShare,
    acceptShare,
    denyShare,
    endShare,
  } = useScreenShare(receiverId);

  const [isMuted, setIsMuted] = useState(false);
  const [isCameraOn, setIsCameraOn] = useState(false);
  const [isStarting, setIsStarting] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const cameraRef = useRef<HTMLVideoElement>(null);

  // Set up video streams
  useEffect(() => {
    if (videoRef.current && remoteStream) {
      videoRef.current.srcObject = remoteStream;
      setStatusMessage('Screen share connected ✅');
      setTimeout(() => setStatusMessage(null), 3000);
    }
  }, [remoteStream]);

  useEffect(() => {
    if (localVideoRef.current && localStream) {
      localVideoRef.current.srcObject = localStream;
    }
  }, [localStream]);

  // Camera overlay
  useEffect(() => {
    if (cameraRef.current && cameraStream) {
      cameraRef.current.srcObject = cameraStream;
    }
  }, [cameraStream]);

  // Cleanup camera on unmount
  useEffect(() => {
    return () => {
      cameraStream?.getTracks().forEach(t => t.stop());
    };
  }, [cameraStream]);

  const handleStartShare = async () => {
    if (!receiverId) return;
    setIsStarting(true);
    setStatusMessage('Starting screen share...');
    try {
      await startShare(receiverId, { audio: !isMuted });
      setStatusMessage('Waiting for user to accept...');
    } catch (error) {
      console.error('Failed to start share:', error);
      setStatusMessage('Failed to start screen share');
      setTimeout(() => setStatusMessage(null), 3000);
    } finally {
      setIsStarting(false);
    }
  };

  const handleEndShare = () => {
    cameraStream?.getTracks().forEach(t => t.stop());
    setCameraStream(null);
    setIsCameraOn(false);
    endShare();
    onClose();
  };

  const toggleMute = () => {
    if (localStream) {
      localStream.getAudioTracks().forEach(track => {
        track.enabled = isMuted;
      });
    }
    setIsMuted(!isMuted);
  };

  const toggleCamera = async () => {
    if (isCameraOn && cameraStream) {
      cameraStream.getTracks().forEach(t => t.stop());
      setCameraStream(null);
      setIsCameraOn(false);
    } else {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
        setCameraStream(stream);
        setIsCameraOn(true);
      } catch (e) {
        console.error('Failed to get camera:', e);
      }
    }
  };

  const toggleFullscreen = () => {
    const el = videoRef.current || localVideoRef.current;
    if (!document.fullscreenElement && el) {
      el.requestFullscreen();
    } else {
      document.exitFullscreen();
    }
  };

  // Incoming request popup
  if (pendingRequest && !isViewing) {
    return (
      <Dialog open={true} onOpenChange={() => denyShare(pendingRequest.id)}>
        <DialogContent className="sm:max-w-sm border-0 bg-gradient-to-b from-card to-background shadow-2xl">
          <div className="flex flex-col items-center gap-6 py-8">
            <div className="relative">
              <motion.div
                animate={{ scale: [1, 1.4, 1], opacity: [0.4, 0, 0.4] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="absolute rounded-full bg-primary/20"
                style={{ width: 120, height: 120, top: -20, left: -20 }}
              />
              <motion.div
                animate={{ scale: [1, 1.2, 1], opacity: [0.6, 0.1, 0.6] }}
                transition={{ duration: 2, repeat: Infinity, delay: 0.3 }}
                className="absolute rounded-full bg-primary/30"
                style={{ width: 100, height: 100, top: -10, left: -10 }}
              />
              <Avatar className="h-20 w-20 border-4 border-primary/30">
                <AvatarFallback className="text-2xl bg-gradient-to-br from-primary to-accent text-primary-foreground">
                  <Monitor className="h-8 w-8" />
                </AvatarFallback>
              </Avatar>
            </div>

            <div className="text-center">
              <h3 className="text-xl font-bold">Incoming Screen Share</h3>
              <motion.p
                animate={{ opacity: [0.5, 1, 0.5] }}
                transition={{ duration: 1.5, repeat: Infinity }}
                className="text-muted-foreground text-sm mt-1"
              >
                Someone wants to share their screen...
              </motion.p>
            </div>

            <div className="flex gap-8">
              <div className="flex flex-col items-center gap-2">
                <motion.div whileTap={{ scale: 0.9 }}>
                  <Button
                    variant="destructive"
                    size="icon"
                    onClick={() => denyShare(pendingRequest.id)}
                    className="h-16 w-16 rounded-full shadow-lg"
                  >
                    <X className="h-6 w-6" />
                  </Button>
                </motion.div>
                <span className="text-xs text-muted-foreground">Decline</span>
              </div>
              <div className="flex flex-col items-center gap-2">
                <motion.div
                  whileTap={{ scale: 0.9 }}
                  animate={{ scale: [1, 1.05, 1] }}
                  transition={{ duration: 1, repeat: Infinity }}
                >
                  <Button
                    size="icon"
                    onClick={() => acceptShare(pendingRequest.id)}
                    className="h-16 w-16 rounded-full bg-green-500 hover:bg-green-600 shadow-lg shadow-green-500/30"
                  >
                    <Check className="h-6 w-6" />
                  </Button>
                </motion.div>
                <span className="text-xs text-muted-foreground">Accept</span>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  // Main screen share dialog
  return (
    <Dialog open={isOpen} onOpenChange={handleEndShare}>
      <DialogContent className="sm:max-w-4xl max-h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Monitor className="h-5 w-5 text-primary" />
            {isSharing ? 'Sharing Your Screen' : isViewing ? 'Viewing Screen' : 'Live Screen Share'}
          </DialogTitle>
        </DialogHeader>

        <div className="relative">
          {/* Status Message */}
          <AnimatePresence>
            {statusMessage && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="absolute top-2 left-1/2 -translate-x-1/2 z-20 bg-card/90 backdrop-blur-sm border border-border rounded-full px-4 py-1.5 text-sm flex items-center gap-2"
              >
                <Wifi className="h-3.5 w-3.5 text-primary" />
                {statusMessage}
              </motion.div>
            )}
          </AnimatePresence>

          {(isSharing || isViewing) ? (
            <div className="relative bg-black rounded-lg overflow-hidden aspect-video">
              <video
                ref={isViewing ? videoRef : localVideoRef}
                autoPlay
                playsInline
                muted={isSharing}
                className="w-full h-full object-contain"
              />

              {/* Camera Overlay (corner) */}
              {isCameraOn && cameraStream && (
                <motion.div
                  drag
                  dragMomentum={false}
                  className="absolute top-3 right-3 w-32 h-24 rounded-lg overflow-hidden border-2 border-background shadow-lg cursor-move z-10"
                >
                  <video ref={cameraRef} autoPlay playsInline muted className="w-full h-full object-cover" />
                </motion.div>
              )}
              
              {/* Floating Controls */}
              <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-2 bg-background/90 backdrop-blur-sm rounded-full px-4 py-2 border border-border shadow-lg z-10">
                <Button
                  variant={isMuted ? 'destructive' : 'secondary'}
                  size="icon"
                  onClick={toggleMute}
                  className="h-10 w-10 rounded-full"
                >
                  {isMuted ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
                </Button>

                <Button
                  variant={isCameraOn ? 'default' : 'secondary'}
                  size="icon"
                  onClick={toggleCamera}
                  className="h-10 w-10 rounded-full"
                >
                  {isCameraOn ? <Video className="h-4 w-4" /> : <VideoOff className="h-4 w-4" />}
                </Button>
                
                <Button
                  variant="destructive"
                  size="icon"
                  onClick={handleEndShare}
                  className="h-12 w-12 rounded-full"
                >
                  <PhoneOff className="h-5 w-5" />
                </Button>
                
                <Button
                  variant="secondary"
                  size="icon"
                  onClick={toggleFullscreen}
                  className="h-10 w-10 rounded-full"
                >
                  <Maximize2 className="h-4 w-4" />
                </Button>
              </div>

              {/* Status Badge */}
              <div className="absolute top-4 left-4 flex items-center gap-2 bg-destructive/90 text-destructive-foreground px-3 py-1 rounded-full text-sm z-10">
                <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
                {isSharing ? 'Sharing' : 'Viewing'}
              </div>

              {/* Mic/Camera indicators */}
              <div className="absolute top-4 right-4 flex gap-1.5 z-10">
                {isMuted && (
                  <span className="bg-destructive/80 text-destructive-foreground text-[10px] px-2 py-0.5 rounded-full">
                    Muted
                  </span>
                )}
              </div>
            </div>
          ) : (
            // Start Screen Share UI
            <div className="flex flex-col items-center justify-center py-12 gap-6">
              <div className="h-24 w-24 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                <Monitor className="h-12 w-12 text-primary-foreground" />
              </div>
              
              <div className="text-center">
                <h3 className="text-xl font-bold mb-2">Share Your Screen</h3>
                <p className="text-muted-foreground max-w-md">
                  Share your screen with {receiverName || 'the other user'}. They'll need to accept your request.
                </p>
              </div>
              
              <div className="flex items-center gap-4">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setIsMuted(!isMuted)}
                  className={cn("h-12 w-12 rounded-full", isMuted && "text-destructive")}
                >
                  {isMuted ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
                </Button>
              </div>
              
              <Button
                size="lg"
                onClick={handleStartShare}
                disabled={isStarting || !receiverId}
                className="gap-2"
              >
                <Monitor className="h-5 w-5" />
                {isStarting ? 'Starting...' : 'Start Sharing'}
              </Button>
              
              {!receiverId && (
                <p className="text-sm text-destructive">
                  Please select a conversation first
                </p>
              )}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ═══════════════════════════════════════════════
// FLOATING VIEWER WINDOW (resizable, draggable)
// ═══════════════════════════════════════════════
export function ScreenShareViewer() {
  const { isViewing, remoteStream, endShare } = useScreenShare();
  const containerRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [size, setSize] = useState({ width: 480, height: 270 });
  const [isMinimized, setIsMinimized] = useState(false);
  const [isResizing, setIsResizing] = useState(false);

  useEffect(() => {
    if (videoRef.current && remoteStream) {
      videoRef.current.srcObject = remoteStream;
    }
  }, [remoteStream]);

  const handleResize = useCallback((e: React.MouseEvent, direction: string) => {
    e.preventDefault();
    e.stopPropagation();
    setIsResizing(true);
    const startX = e.clientX;
    const startY = e.clientY;
    const startW = size.width;
    const startH = size.height;

    const onMouseMove = (ev: MouseEvent) => {
      let newW = startW;
      let newH = startH;
      if (direction.includes('e')) newW = Math.min(900, Math.max(300, startW + (ev.clientX - startX)));
      if (direction.includes('s')) newH = Math.min(600, Math.max(200, startH + (ev.clientY - startY)));
      setSize({ width: newW, height: newH });
    };

    const onMouseUp = () => {
      setIsResizing(false);
      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseup', onMouseUp);
    };

    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseup', onMouseUp);
  }, [size]);

  const handleDoubleClick = () => {
    if (size.width > 600) {
      setSize({ width: 480, height: 270 });
    } else {
      setSize({ width: 900, height: 506 });
    }
  };

  if (!isViewing || !remoteStream) return null;

  if (isMinimized) {
    return (
      <motion.div
        drag
        dragMomentum={false}
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        className="fixed bottom-24 left-4 z-50 bg-card border border-border rounded-2xl shadow-2xl p-3 flex items-center gap-3 cursor-move"
      >
        <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center">
          <Monitor className="h-5 w-5 text-primary" />
        </div>
        <div>
          <p className="text-sm font-semibold">Screen Share</p>
          <p className="text-xs text-green-500">Live</p>
        </div>
        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setIsMinimized(false)}>
          <Maximize2 className="h-4 w-4" />
        </Button>
        <Button variant="destructive" size="icon" className="h-8 w-8 rounded-full" onClick={endShare}>
          <PhoneOff className="h-4 w-4" />
        </Button>
      </motion.div>
    );
  }

  return (
    <AnimatePresence>
      <motion.div
        ref={containerRef}
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.8 }}
        drag={!isResizing}
        dragMomentum={false}
        onDoubleClick={handleDoubleClick}
        className="fixed z-50 bg-background border border-border rounded-xl shadow-2xl overflow-hidden select-none"
        style={{
          left: 20,
          top: 80,
          width: size.width,
          height: size.height,
        }}
      >
        {/* Resize handles */}
        <div className="absolute right-0 top-0 w-2 h-full cursor-e-resize z-20" onMouseDown={(e) => handleResize(e, 'e')} />
        <div className="absolute bottom-0 left-0 w-full h-2 cursor-s-resize z-20" onMouseDown={(e) => handleResize(e, 's')} />
        <div className="absolute bottom-0 right-0 w-4 h-4 cursor-se-resize z-20" onMouseDown={(e) => handleResize(e, 'se')} />

        <video
          ref={videoRef}
          autoPlay
          playsInline
          className="w-full h-full object-contain bg-black"
        />
        
        {/* Controls */}
        <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex items-center gap-1 bg-background/80 backdrop-blur-sm rounded-full px-3 py-1.5 z-10">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full" onClick={() => setIsMinimized(true)}>
            <Minimize2 className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={endShare}
            className="h-8 w-8 rounded-full text-destructive hover:bg-destructive/10"
          >
            <PhoneOff className="h-4 w-4" />
          </Button>
        </div>
        
        {/* Status */}
        <div className="absolute top-2 left-2 flex items-center gap-1 bg-destructive/80 text-destructive-foreground px-2 py-0.5 rounded-full text-xs z-10">
          <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
          Live
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
